package com.example.project_tkexchange;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button Login;
    EditText etEmail, etPassword;
    TextView tvSignUpLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);
        Login = (Button) findViewById(R.id.Login);
        tvSignUpLink = (TextView) findViewById(R.id.tvSignUpLink);

        Login.setOnClickListener(this);
        tvSignUpLink.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.Login:

                break;

            case R.id.tvSignUpLink:

                startActivity(new Intent(this, SignUp.class));

                break;
        }
    }
}
