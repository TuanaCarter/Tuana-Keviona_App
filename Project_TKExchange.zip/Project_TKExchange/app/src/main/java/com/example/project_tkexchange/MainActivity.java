package com.example.project_tkexchange;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button LogOut;
    EditText etFirst, etLast, etEmailA;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirst = (EditText) findViewById(R.id.etFirst);
        etLast = (EditText) findViewById(R.id.etLast);
        etEmailA = (EditText) findViewById(R.id.etEmailA);

        LogOut = (Button) findViewById(R.id.LogOut);


        LogOut.setOnClickListener(this);




    }

        @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.LogOut:

                startActivity(new Intent(this, Login.class));
             break;

        }
    }
}
