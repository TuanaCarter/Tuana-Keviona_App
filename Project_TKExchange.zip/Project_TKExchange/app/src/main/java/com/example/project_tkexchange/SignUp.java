package com.example.project_tkexchange;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SignUp extends AppCompatActivity implements View.OnClickListener {

    Button SignUp;
    EditText etFirst;
    EditText etLast;
    EditText etEmailA;
    EditText etPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etFirst = (EditText) findViewById(R.id.etFirst);
        etLast = (EditText) findViewById(R.id.etLast);
        etEmailA = (EditText) findViewById(R.id.etEmailA);
        etPassword = (EditText) findViewById(R.id.etPassword);

        SignUp = (Button) findViewById(R.id.SignUp);

        SignUp.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){

            case R.id.SignUp:

                startActivity(new Intent(SignUp.this, Login.class));

                break;
        }
    }
}

